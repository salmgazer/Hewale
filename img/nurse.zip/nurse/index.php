<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<!-- Authors
Group 3
Salifu Mutaru
Ali Njie
Willaim Annor
Adjoa Maame
Comfort Tenjie
-->

<html>
    <head>
        <meta charset="UTF-8">
        <title>Index</title>
        <link href="css/style.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
    
        <table>
        <tr colspan="2" class="pageheader">
       <td><img class="userpicture" src="img/user.jpg"></td>
       <center><td><h1 class="heading">Task Manager</h1></td></center>
        </tr>

            <tr>
                <td id="mainnav">
                <div id="navheader">Menu</div>
                    <div class="menuitem1">menu 1</div>
                    <div class="menuitem1">menu 2</div>
                    <div class="menuitem1">menu 3</div>
                    <div class="menuitem1">menu 4</div>
                </td>
                <td id="content">
                    <div id="divPageMenu">
                       <!-- <span class="menuitem" >page menu 1</span>
                        <span class="menuitem" >page menu 2</span>
                        <span class="menuitem" >page menu 3</span>
                        <input type="text" id="txtSearch" />
                        <span class="menuitem">search</span>	-->	
                        <form id="search" class="searchbar">
                            <input placeholder="Search here">
                            <button class="btn clickspot" type="submit">Submit</button>
                        </form>
                    </div>
                    <!--<div id="divStatus" class="status">
                        status message
                    </div>-->
                    <div id="divContent">
                       <!-- Content space
                        <span class="clickspot">click here </span>-->
                        <center>
                        <table id="tableExample" class="reportTable">
                            <tr class="header">
                                <td>Task ID</td>
                                <td>Task Description</td>
                                <td>Added</td>
                                <td>Deadline</td>
                                <td>Details</td>
                            </tr>
                            <tr class="row1">
                                <td>data example</td>
                                <td id="leftsapced">Some descriptions will come here... so yeah i know that</td>
                                <td id="leftspaced">01/01/2014</td>
                                <td>01/01/2014</td>
                                <td><a href="#"><button class="roundedbtn clickspot">Details</button></a></td>
                            </tr >
                            <tr class="row2">
                                <td>data example</td>
                                <td>Some descriptions will come here... so yeah i know that</td>
                                <td>01/01/2014</td>
                                <td>01/01/2014</td>
                                <td><a href="#"></a><button class="roundedbtn clickspot">Details</button></td></td>
                            </tr>
                            <tr class="row1">
                                <td>data example</td>
                                <td id="leftsapced">Some descriptions will come here... so yeah i know that</td>
                                <td id="leftspaced">01/01/2014</td>
                                <td>01/01/2014</td>
                                <td><a href="#"><button class="roundedbtn clickspot">Details</button></a></td>
                            </tr >
                            <tr class="row2">
                                <td>data example</td>
                                <td>Some descriptions will come here... so yeah i know that</td>
                                <td>01/01/2014</td>
                                <td>01/01/2014</td>
                                <td><a href="#"></a><button class="roundedbtn clickspot">Details</button></td></td>
                            </tr>
                            <tr class="row1">
                                <td>data example</td>
                                <td id="leftsapced">Some descriptions will come here... so yeah i know that</td>
                                <td id="leftspaced">01/01/2014</td>
                                <td>01/01/2014</td>
                                <td><a href="#"><button class="roundedbtn clickspot">Details</button></a></td>
                            </tr >
                            <tr class="row2">
                                <td>data example</td>
                                <td>Some descriptions will come here... so yeah i know that</td>
                                <td>01/01/2014</td>
                                <td>01/01/2014</td>
                                <td><a href="#"></a><button class="roundedbtn clickspot">Details</button></td></td>
                            </tr>
                    </div>
                </td>
            </tr>
        </table>
        </center>
        <?php
        // put your code here
        ?>
    </body>
</html>
